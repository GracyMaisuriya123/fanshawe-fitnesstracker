// App.js
import React, { useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navigation from './components/Navbar';
import Home from './components/Home';
import Profile from './components/Profile';
import WorkoutLog from './components/WorkoutLog';
import GoalsTracker from './components/GoalsTracker';
import MessageBoard from './components/MessageBoard'; // Import the MessageBoard component
import './App.css'; // Import global styles
import { requestPermission } from './components/firebaseConfig'; // Import the requestPermission function

function App() {
  useEffect(() => {
    // Request permission for push notifications when the app loads
    requestPermission();
  }, []);

  return (
    <Router>
      <div className="app-container">
        <Navigation />
        <div className="content">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/profile" element={<Profile />} />
            <Route path="/workout-log" element={<WorkoutLog />} />
            <Route path="/goals" element={<GoalsTracker />} />
            <Route path="/message-board" element={<MessageBoard />} /> {/* Add this route */}
          </Routes>
        </div>
      </div>
    </Router>
  );
}

export default App;





