import React, { useState, useEffect } from 'react';
import { auth, db } from './firebaseConfig'; // ✅ Now `db` is properly imported
 // Ensure Firebase is configured properly
import { 
    signInWithEmailAndPassword, 
    createUserWithEmailAndPassword, 
    onAuthStateChanged, 
    signOut 
} from 'firebase/auth'; 
import { doc, setDoc, getDoc } from 'firebase/firestore'; 
import GoalsTracker from './GoalsTracker';
import WorkoutLog from './WorkoutLog';

function Profile() {
    const [user, setUser] = useState(null);
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [isLoggingIn, setIsLoggingIn] = useState(true);
    const [message, setMessage] = useState('');
    const [userData, setUserData] = useState(null); // Firestore user data

    useEffect(() => {
        const unsubscribe = onAuthStateChanged(auth, async (user) => {
            if (user) {
                setUser(user);
                const token = await user.getIdToken();
                localStorage.setItem('token', token);
                
                // Fetch user data from Firestore
                const userRef = doc(db, 'users', user.uid);
                const userSnap = await getDoc(userRef);
                if (userSnap.exists()) {
                    setUserData(userSnap.data());
                }
            } else {
                setUser(null);
                setUserData(null);
                localStorage.removeItem('token');
            }
        });

        return unsubscribe;
    }, []);

    const handleAuth = async (e) => {
      e.preventDefault();
      setMessage('');
      
      try {
          let userCredential;
          if (isLoggingIn) {
              userCredential = await signInWithEmailAndPassword(auth, email, password);
              setMessage('Login successful!');
          } else {
              userCredential = await createUserWithEmailAndPassword(auth, email, password);
              setMessage('Registration successful!');
              
              const user = userCredential.user;
              const userRef = doc(db, 'users', user.uid);
  
              // ✅ Debugging: Log user and Firestore write status
              console.log("User registered:", user.email);
              await setDoc(userRef, {
                  email: user.email,
                  createdAt: new Date(),
                  goals: [],
                  workouts: []
              });
              console.log("User data added to Firestore.");
          }
  
          const token = await userCredential.user.getIdToken();
          localStorage.setItem('token', token);
          setEmail('');
          setPassword('');
      } catch (error) {
          console.error("Firestore error:", error.message);
          setMessage(`Error: ${error.message}`);
      }
  };
  

    const handleLogout = async () => {
        try {
            await signOut(auth);
            setMessage('Logged out successfully.');
        } catch (error) {
            setMessage(`Error logging out: ${error.message}`);
        }
    };

    return (
        <div>
            <h1>Profile</h1>

            {message && <p style={{ color: 'red' }}>{message}</p>}

            {!user ? (
                <div>
                    <h2>{isLoggingIn ? 'Login' : 'Register'}</h2>
                    <form onSubmit={handleAuth}>
                        <input
                            type="email"
                            placeholder="Email"
                            value={email}
                            onChange={(e) => setEmail(e.target.value)}
                            required
                        />
                        <input
                            type="password"
                            placeholder="Password"
                            value={password}
                            onChange={(e) => setPassword(e.target.value)}
                            required
                        />
                        <button type="submit">{isLoggingIn ? 'Login' : 'Register'}</button>
                    </form>
                    <button onClick={() => setIsLoggingIn(!isLoggingIn)}>
                        {isLoggingIn ? 'Switch to Register' : 'Switch to Login'}
                    </button>
                </div>
            ) : (
                <div>
                    <h2>Welcome, {userData?.email || user.email}</h2>
                    <button onClick={handleLogout}>Logout</button>

                    {/* Display Goals & Workouts */}
                    <GoalsTracker />
                    <WorkoutLog />
                </div>
            )}
        </div>
    );
}

export default Profile;




