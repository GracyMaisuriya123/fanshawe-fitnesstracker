import React, { useState, useEffect } from 'react';
import { sendMessage, onMessageReceived } from '../services/socketService';

const aiResponses = [
    "That sounds interesting! Tell me more.",
    "How do you feel about that?",
    "I see! What’s your goal with this?",
    "That’s a great point. Have you tried a different approach?",
    "Keep pushing forward! You’re doing great.",
    "Nice! What’s your next step?",
    "I understand. What’s been the biggest challenge?",
    "That makes sense. Do you need any advice on that?",
    "You're really making progress! What motivates you?",
];

const getAIResponse = (userMessage, chatHistory) => {
    if (chatHistory.length < 2) return "Hi there! What would you like to talk about today?";
    
    return aiResponses[Math.floor(Math.random() * aiResponses.length)];
};

const MessageBoard = () => {
    const [messages, setMessages] = useState([]);
    const [newMessage, setNewMessage] = useState('');

    useEffect(() => {
        // Listen for new messages
        onMessageReceived((message) => {
            setMessages((prevMessages) => [...prevMessages, message]);
        });

        return () => {
            // Cleanup logic if needed
        };
    }, []);

    const handleSendMessage = () => {
        if (newMessage.trim() !== '') {
            const userMessage = { sender: 'You', text: newMessage };
            setMessages((prevMessages) => [...prevMessages, userMessage]);
            sendMessage(newMessage);  // Send to the server
            setNewMessage('');

            // Simulate AI response after a delay
            setTimeout(() => {
                const aiMessage = { sender: 'AI', text: getAIResponse(newMessage, messages) };
                setMessages((prevMessages) => [...prevMessages, aiMessage]);
            }, 1500);
        }
    };

    return (
        <div style={{ maxWidth: '600px', margin: '0 auto', padding: '20px' }}>
            <h2>Fitness Chat</h2>
            <div
                style={{
                    height: '300px',
                    overflowY: 'auto',
                    border: '1px solid #ddd',
                    marginBottom: '10px',
                    padding: '10px',
                    backgroundColor: '#f9f9f9',
                }}
            >
                {messages.length > 0 ? (
                    messages.map((msg, index) => (
                        <div key={index} style={{ padding: '5px 0' }}>
                            <strong>{msg.sender}:</strong> {msg.text}
                        </div>
                    ))
                ) : (
                    <p>No messages yet. Be the first to send a message!</p>
                )}
            </div>

            <div>
                <input
                    type="text"
                    value={newMessage}
                    onChange={(e) => setNewMessage(e.target.value)}
                    placeholder="Type a message..."
                    style={{
                        width: '80%',
                        padding: '10px',
                        marginRight: '10px',
                        borderRadius: '5px',
                        border: '1px solid #ddd',
                    }}
                />
                <button
                    onClick={handleSendMessage}
                    style={{
                        padding: '10px 20px',
                        backgroundColor: '#4CAF50',
                        color: 'white',
                        border: 'none',
                        borderRadius: '5px',
                        cursor: 'pointer',
                    }}
                >
                    Send
                </button>
            </div>
        </div>
    );
};

export default MessageBoard;


