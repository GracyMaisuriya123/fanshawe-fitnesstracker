import { useState } from 'react';

const AddGoalForm = ({ onGoalAdded }) => {
    const [goal, setGoal] = useState('');
    const [targetDate, setTargetDate] = useState('');

    const handleSubmit = async (e) => {
        e.preventDefault();
        const token = localStorage.getItem('token');

        if (!token) {
            alert("You are not authenticated. Please log in.");
            return;
        }

        try {
            const response = await fetch('http://localhost:3001/goals', {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${token}`,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ goal_description: goal, target_date: targetDate })
            });

            if (!response.ok) {
                throw new Error('Failed to add goal');
            }

            const data = await response.json();
            alert('Goal added successfully!');
            setGoal('');
            setTargetDate('');
            onGoalAdded(); // Refresh goals list
        } catch (error) {
            console.error('Error adding goal:', error);
        }
    };

    return (
        <form onSubmit={handleSubmit}>
            <label>Goal:</label>
            <input 
                type="text" 
                value={goal} 
                onChange={(e) => setGoal(e.target.value)} 
                required
            />
            
            <label>Target Date:</label>
            <input 
                type="date" 
                value={targetDate} 
                onChange={(e) => setTargetDate(e.target.value)} 
                required
            />
            
            <button type="submit">Add Goal</button>
        </form>
    );
};

export default AddGoalForm;
