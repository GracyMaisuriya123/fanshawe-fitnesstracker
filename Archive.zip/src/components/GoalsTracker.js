import React, { useState, useEffect } from 'react';
import AddGoalForm from '../components/AddGoalForm'; // Import AddGoalForm

const GoalsTracker = () => {
    const [goals, setGoals] = useState([]);
    const [error, setError] = useState(null);

    const fetchGoals = async () => {
        const token = localStorage.getItem('token');  // ✅ Get token from localStorage

        if (!token) {
            setError("You are not authenticated. Please log in.");
            console.error("No token found, user not authenticated.");
            return;
        }

        try {
            const response = await fetch('http://localhost:3001/goals', {
                method: 'GET',
                headers: {
                    'Authorization': `Bearer ${token}`,  // ✅ Send token
                    'Content-Type': 'application/json'
                }
            });

            if (!response.ok) {
                throw new Error(`Failed to fetch goals. Status: ${response.status}`);
            }

            const data = await response.json();
            console.log("Goals fetched:", data);
            setGoals(data.goals);
        } catch (error) {
            console.error("Error fetching goals:", error);
            setError("Failed to fetch goals. Please try again later.");
        }
    };

    useEffect(() => {
        fetchGoals();
    }, []);

    return (
        <div>
            <h2>Your Goals</h2>
            {error && <p style={{ color: 'red' }}>{error}</p>}
            <AddGoalForm onGoalAdded={fetchGoals} />  {/* AddGoalForm will refresh goals after adding */}
            <ul>
                {goals.length === 0 ? (
                    <p>No goals found.</p>
                ) : (
                    goals.map(goal => (
                        <li key={goal.id}>{goal.goal_description} - Target Date: {goal.target_date}</li>
                    ))
                )}
            </ul>
        </div>
    );
};

export default GoalsTracker;







