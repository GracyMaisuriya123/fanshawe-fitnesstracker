require('dotenv').config();
const express = require('express');
const cors = require('cors');
const http = require('http');
const socketIo = require('socket.io');
const firebaseAdmin = require('firebase-admin');
const mysql = require('mysql2/promise');
const jwt = require('jsonwebtoken');

const serviceAccount = require('./firebaseServiceAccountKey.json');

// Initialize Firebase Admin SDK
firebaseAdmin.initializeApp({
    credential: firebaseAdmin.credential.cert(serviceAccount),
});

const db = firebaseAdmin.firestore(); // Firestore reference

// MySQL connection pool
const mysqlPool = mysql.createPool({
    host: process.env.DB_HOST || 'localhost',
    user: process.env.DB_USER || 'root',
    password: process.env.DB_PASS || 'Gracy123',
    database: process.env.DB_NAME || 'fitness_tracker',
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0,
});

const app = express();
const server = http.createServer(app);
const io = socketIo(server, {
    cors: {
        origin: "*", // Allow all origins for now
        methods: ["GET", "POST"],
    }
});

// Middleware
app.use(cors());
app.use(express.json()); // Ensure JSON parsing
app.use(express.urlencoded({ extended: true })); // Parse URL-encoded data

// 🛠 Debugging Middleware (Logs requests)
app.use((req, res, next) => {
    console.log(`[${req.method}] ${req.url}`, req.body);
    next();
});

// 🚀 Root Route
app.get('/', (req, res) => {
    res.send('Server is running successfully!');
});

// 🔒 JWT Authentication Middleware
const authenticateToken = (req, res, next) => {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];

    if (!token) {
        return res.status(403).json({ error: 'No token provided' });
    }

    jwt.verify(token, process.env.JWT_SECRET, (err, user) => {
        if (err) {
            console.error('Token verification failed:', err);
            return res.status(403).json({ error: 'Invalid or expired token' });
        }

        req.user = user;
        next();
    });
};

// ✅ Debug Route: Check if API is reachable
app.get('/test', (req, res) => {
    res.json({ message: 'API is working!' });
});

// 📝 User Registration (GET for debugging, POST for actual use)
app.get('/register', (req, res) => {
    res.json({ message: 'Use POST method to register a user' });
});
app.post('/register', async (req, res) => {
    const { email, password, fcmToken } = req.body;

    if (!email || !password) {
        return res.status(400).json({ error: 'Email and password are required' });
    }

    try {
        // Create Firebase user
        const userRecord = await firebaseAdmin.auth().createUser({ email, password });

        // Store user in Firestore
        await db.collection('users').doc(userRecord.uid).set({
            email: email,
            fcmToken: fcmToken || '',
        });

        res.status(201).json({ message: 'User registered successfully', uid: userRecord.uid });
    } catch (error) {
        console.error('Error registering user:', error);
        res.status(500).json({ error: error.message });
    }
});

// 🔑 User Login (GET for debugging, POST for actual use)
app.get('/login', (req, res) => {
    res.json({ message: 'Use POST method to log in' });
});
app.post('/login', async (req, res) => {
    const { email, password } = req.body;

    if (!email || !password) {
        return res.status(400).json({ error: 'Email and password are required' });
    }

    try {
        const userSnapshot = await db.collection('users').where('email', '==', email).get();
        if (userSnapshot.empty) {
            return res.status(404).json({ error: 'User not found' });
        }

        const userData = userSnapshot.docs[0].data();
        const firebaseUid = userSnapshot.docs[0].id;

        // Generate JWT
        const token = jwt.sign({ firebaseUid }, process.env.JWT_SECRET, { expiresIn: '1h' });

        res.status(200).json({ message: 'Login successful', token });
    } catch (error) {
        console.error('Error logging in:', error);
        res.status(500).json({ error: error.message });
    }
});

// 🎯 Fetch User Goals
app.get('/goals', authenticateToken, async (req, res) => {
    try {
        const firebaseUid = req.user.firebaseUid;

        const [goalRows] = await mysqlPool.execute('SELECT * FROM goals WHERE firebase_uid = ?', [firebaseUid]);

        if (goalRows.length === 0) {
            return res.status(404).json({ message: 'No goals found for this user.' });
        }

        res.status(200).json({ message: 'User goals fetched successfully', goals: goalRows });
    } catch (error) {
        console.error('Error fetching goals:', error);
        res.status(500).json({ message: 'Error fetching goals', error: error.message });
    }
});

// ➕ Add New Goal
app.post('/goals', authenticateToken, async (req, res) => {
    const { goal_description, target_date } = req.body;
    const firebaseUid = req.user.firebaseUid;

    if (!goal_description || !target_date) {
        return res.status(400).json({ error: 'Please provide goal description and target date.' });
    }

    try {
        const [result] = await mysqlPool.execute(
            'INSERT INTO goals (firebase_uid, goal_description, target_date) VALUES (?, ?, ?)',
            [firebaseUid, goal_description, target_date]
        );

        res.status(201).json({ message: 'Goal added successfully', goalId: result.insertId });
    } catch (error) {
        console.error('Error adding goal:', error);
        res.status(500).json({ error: 'Failed to add goal' });
    }
});

// 📢 Send Push Notification
app.get('/send-notification', (req, res) => {
    res.json({ message: 'Use POST method to send notifications' });
});
app.post('/send-notification', authenticateToken, async (req, res) => {
    const { title, body } = req.body;
    const firebaseUid = req.user.firebaseUid;

    if (!title || !body) {
        return res.status(400).json({ error: 'Please provide title and body for notification.' });
    }

    try {
        const userSnapshot = await db.collection('users').doc(firebaseUid).get();
        if (!userSnapshot.exists) {
            return res.status(404).json({ error: 'User not found.' });
        }

        const user = userSnapshot.data();
        const fcmToken = user.fcmToken;
        if (!fcmToken) return res.status(400).json({ error: 'FCM token not available.' });

        const message = { notification: { title, body }, token: fcmToken };

        await firebaseAdmin.messaging().send(message);
        res.status(200).json({ message: 'Notification sent successfully!' });
    } catch (error) {
        console.error('Error sending notification:', error);
        res.status(500).json({ message: 'Error sending notification', error: error.message });
    }
});

// 🚀 Start the server
const PORT = process.env.PORT || 3001;
server.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});











